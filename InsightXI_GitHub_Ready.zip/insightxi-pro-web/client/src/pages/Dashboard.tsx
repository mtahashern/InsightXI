import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Upload, Play, Download, BarChart3, Users, Target } from 'lucide-react';

export default function Dashboard() {
  const [uploadedVideos, setUploadedVideos] = useState<string[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<any>(null);

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files).map(f => f.name);
      setUploadedVideos(prev => [...prev, ...files]);
    }
  };

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    // Simulate analysis
    setTimeout(() => {
      setAnalysisResults({
        teamA: {
          style: 'Gegenpressing',
          compactness: 8.2,
          width: 7.5,
          cohesion: 'Elite Unit Cohesion'
        },
        teamB: {
          style: 'Park the Bus',
          compactness: 7.8,
          width: 6.2,
          cohesion: 'Solid Defensive Block'
        },
        matchupVerdict: 'Team A dominates structurally with superior pressing intensity',
        weaknesses: [
          { team: 'A', issue: 'Counter-Attack Vulnerability', zone: 'Left Channel' },
          { team: 'B', issue: 'Narrow Structural Bias', zone: 'Central Midfield' }
        ]
      });
      setIsAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card/50 backdrop-blur">
        <div className="container py-8">
          <h1 className="gradient-title mb-2">⚽ InsightXI ELITE</h1>
          <p className="text-muted-foreground">Autonomous Dual-Team Tactical Intelligence & Recovery</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-12">
        {/* Upload Section */}
        <Card className="mb-12 border-border bg-card p-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Upload className="w-6 h-6 text-primary" />
                Upload Match Footage
              </h2>
              <p className="text-muted-foreground mb-6">
                Drop one or multiple video clips for batch analysis. Supported formats: MP4, MOV, AVI.
              </p>
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer">
                <input
                  type="file"
                  multiple
                  accept="video/*"
                  onChange={handleVideoUpload}
                  className="hidden"
                  id="video-upload"
                />
                <label htmlFor="video-upload" className="cursor-pointer">
                  <div className="text-4xl mb-2">📹</div>
                  <p className="font-semibold">Click to upload or drag and drop</p>
                  <p className="text-sm text-muted-foreground">MP4, MOV, AVI up to 500MB</p>
                </label>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Uploaded Videos ({uploadedVideos.length})</h3>
              <div className="space-y-2 mb-6 max-h-48 overflow-y-auto">
                {uploadedVideos.map((video, idx) => (
                  <div key={idx} className="flex items-center gap-2 p-3 bg-card border border-border rounded">
                    <span className="text-primary">✓</span>
                    <span className="text-sm truncate">{video}</span>
                  </div>
                ))}
                {uploadedVideos.length === 0 && (
                  <p className="text-muted-foreground text-sm">No videos uploaded yet</p>
                )}
              </div>
              <Button
                onClick={handleAnalyze}
                disabled={uploadedVideos.length === 0 || isAnalyzing}
                className="w-full bg-primary hover:bg-primary/90"
              >
                <Play className="w-4 h-4 mr-2" />
                {isAnalyzing ? 'Analyzing...' : 'Start Analysis'}
              </Button>
            </div>
          </div>
        </Card>

        {/* Analysis Results */}
        {analysisResults && (
          <div className="space-y-8">
            {/* Matchup Verdict */}
            <Card className="metric-card">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-primary" />
                Matchup Verdict
              </h2>
              <p className="text-lg text-foreground">{analysisResults.matchupVerdict}</p>
            </Card>

            {/* Team Metrics */}
            <div className="grid md:grid-cols-2 gap-6">
              {['A', 'B'].map(team => {
                const data = team === 'A' ? analysisResults.teamA : analysisResults.teamB;
                return (
                  <Card key={team} className="metric-card">
                    <h3 className="text-lg font-bold mb-4">Team {team}</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Playing Style</span>
                        <span className="font-semibold text-primary">{data.style}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Compactness Score</span>
                        <span className="font-semibold">{data.compactness}/10</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Pitch Width</span>
                        <span className="font-semibold">{data.width}/10</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Unit Cohesion</span>
                        <span className="font-semibold text-primary">{data.cohesion}</span>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>

            {/* Weaknesses & Recovery */}
            <Card className="metric-card">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                <Target className="w-5 h-5 text-destructive" />
                Detected Issues & Recovery Protocols
              </h2>
              <div className="space-y-4">
                {analysisResults.weaknesses.map((w: any, idx: number) => (
                  <div key={idx} className="recovery-card warning">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <p className="font-semibold">Team {w.team}: {w.issue}</p>
                        <p className="text-sm text-muted-foreground">Zone: {w.zone}</p>
                      </div>
                    </div>
                    <p className="text-sm mt-3">
                      <strong>Recovery Protocol:</strong> Adjust formation to create defensive depth and reduce vulnerability in the {w.zone.toLowerCase()}.
                    </p>
                  </div>
                ))}
              </div>
            </Card>

            {/* Export Button */}
            <div className="flex gap-4">
              <Button className="flex-1 bg-primary hover:bg-primary/90">
                <Download className="w-4 h-4 mr-2" />
                Export PDF Scouting Report
              </Button>
              <Button variant="outline" className="flex-1">
                <Users className="w-4 h-4 mr-2" />
                View Player Roles
              </Button>
            </div>
          </div>
        )}

        {/* Empty State */}
        {!analysisResults && uploadedVideos.length === 0 && (
          <Card className="metric-card text-center py-12">
            <div className="text-6xl mb-4">🎬</div>
            <h3 className="text-xl font-bold mb-2">Ready to Analyze</h3>
            <p className="text-muted-foreground">Upload your match footage to begin tactical analysis</p>
          </Card>
        )}
      </div>
    </div>
  );
}
