import React, { useEffect, useRef } from 'react';
import type { PlayerData } from '@/../../server/analysis';

interface TacticalPitchProps {
  teamAPlayers: PlayerData[];
  teamBPlayers: PlayerData[];
  width?: number;
  height?: number;
}

export function TacticalPitch({
  teamAPlayers,
  teamBPlayers,
  width = 800,
  height = 600
}: TacticalPitchProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = '#1a4d2e';
    ctx.fillRect(0, 0, width, height);

    // Draw pitch markings
    drawPitchMarkings(ctx, width, height);

    // Draw players
    const allPlayers = [...teamAPlayers, ...teamBPlayers];
    allPlayers.forEach(player => {
      drawPlayer(ctx, player, width, height);
    });
  }, [teamAPlayers, teamBPlayers, width, height]);

  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      className="pitch-board w-full rounded-lg shadow-2xl"
    />
  );
}

function drawPitchMarkings(ctx: CanvasRenderingContext2D, width: number, height: number) {
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 2;

  // Pitch outline
  ctx.strokeRect(0, 0, width, height);

  // Halfway line
  ctx.beginPath();
  ctx.moveTo(width / 2, 0);
  ctx.lineTo(width / 2, height);
  ctx.stroke();

  // Center circle
  ctx.beginPath();
  ctx.arc(width / 2, height / 2, height / 6, 0, Math.PI * 2);
  ctx.stroke();

  // Center spot
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(width / 2, height / 2, 3, 0, Math.PI * 2);
  ctx.fill();

  // Penalty areas
  const penaltyWidth = width * 0.165;
  const penaltyHeight = height * 0.6;
  ctx.strokeRect(0, (height - penaltyHeight) / 2, penaltyWidth, penaltyHeight);
  ctx.strokeRect(width - penaltyWidth, (height - penaltyHeight) / 2, penaltyWidth, penaltyHeight);

  // Goal areas
  const goalWidth = width * 0.055;
  const goalHeight = height * 0.35;
  ctx.strokeRect(0, (height - goalHeight) / 2, goalWidth, goalHeight);
  ctx.strokeRect(width - goalWidth, (height - goalHeight) / 2, goalWidth, goalHeight);
}

function drawPlayer(ctx: CanvasRenderingContext2D, player: PlayerData, width: number, height: number) {
  // Scale coordinates to canvas
  const x = (player.x / 105) * width;
  const y = (player.y / 68) * height;

  // Draw player circle
  const radius = 12;
  ctx.fillStyle = player.team === 'A' ? '#22c55e' : '#ef4444';
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();

  // Draw border
  ctx.strokeStyle = player.team === 'A' ? '#86efac' : '#fca5a5';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Draw jersey number
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 10px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(player.id.toString(), x, y);
}

export default TacticalPitch;
