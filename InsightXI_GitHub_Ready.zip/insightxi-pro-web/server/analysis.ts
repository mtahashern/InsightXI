/**
 * Elite Tactical Analysis Engine
 * Handles dual-team detection, player role identification, and tactical intelligence
 */

export interface PlayerData {
  id: number;
  x: number;
  y: number;
  team: 'A' | 'B';
  role: PlayerRole;
  activity: number; // 0-10 scale
}

export type PlayerRole = 
  | 'Sweeper Keeper'
  | 'Ball-Winning Defender'
  | 'Box-to-Box Midfielder'
  | 'Inverted Winger'
  | 'Target Forward';

export type PlayingStyle = 
  | 'Gegenpressing'
  | 'Park the Bus'
  | 'Tiki-Taka'
  | 'Tactical Hybrid';

export type PressingZone = 
  | 'High-Press Final Third'
  | 'Mid-Block'
  | 'Low-Block Defensive Third';

export type TacticalWeakness = 
  | 'Narrow Structural Bias'
  | 'Counter-Attack Vulnerability'
  | 'Broken Defensive Lines';

export type TacticalStrength = 'Elite Unit Cohesion';

export interface TeamAnalysis {
  team: 'A' | 'B';
  playingStyle: PlayingStyle;
  pressingZone: PressingZone;
  compactness: number; // 0-10
  width: number; // 0-10
  cohesion: TacticalStrength | string;
  players: PlayerData[];
  weaknesses: TacticalWeakness[];
  strengths: string[];
}

export interface AnalysisResult {
  teamA: TeamAnalysis;
  teamB: TeamAnalysis;
  matchupVerdict: string;
  recoveryProtocols: RecoveryProtocol[];
  coachingCommentary: string;
}

export interface RecoveryProtocol {
  team: 'A' | 'B';
  issue: TacticalWeakness;
  zone: string;
  recommendation: string;
  formationAdjustment?: string;
}

/**
 * Detect and separate two teams based on spatial clustering
 */
export function detectDualTeams(playerPositions: Array<[number, number]>): {
  teamA: Array<[number, number]>;
  teamB: Array<[number, number]>;
} {
  if (playerPositions.length === 0) {
    return { teamA: [], teamB: [] };
  }

  // K-means clustering to separate two teams
  let centroidA = playerPositions[0];
  let centroidB = playerPositions[Math.floor(playerPositions.length / 2)];

  for (let iteration = 0; iteration < 10; iteration++) {
    const teamA: Array<[number, number]> = [];
    const teamB: Array<[number, number]> = [];

    // Assign players to nearest centroid
    playerPositions.forEach(pos => {
      const distA = Math.hypot(pos[0] - centroidA[0], pos[1] - centroidA[1]);
      const distB = Math.hypot(pos[0] - centroidB[0], pos[1] - centroidB[1]);
      if (distA < distB) {
        teamA.push(pos);
      } else {
        teamB.push(pos);
      }
    });

    // Recalculate centroids
    if (teamA.length > 0) {
      centroidA = [
        teamA.reduce((sum, p) => sum + p[0], 0) / teamA.length,
        teamA.reduce((sum, p) => sum + p[1], 0) / teamA.length
      ];
    }
    if (teamB.length > 0) {
      centroidB = [
        teamB.reduce((sum, p) => sum + p[0], 0) / teamB.length,
        teamB.reduce((sum, p) => sum + p[1], 0) / teamB.length
      ];
    }
  }

  // Final assignment
  const teamA: Array<[number, number]> = [];
  const teamB: Array<[number, number]> = [];

  playerPositions.forEach(pos => {
    const distA = Math.hypot(pos[0] - centroidA[0], pos[1] - centroidA[1]);
    const distB = Math.hypot(pos[0] - centroidB[0], pos[1] - centroidB[1]);
    if (distA < distB) {
      teamA.push(pos);
    } else {
      teamB.push(pos);
    }
  });

  return { teamA, teamB };
}

/**
 * Identify player roles based on average position and movement patterns
 */
export function identifyPlayerRole(
  playerPositions: Array<[number, number]>,
  teamCentroid: [number, number],
  playerIndex: number
): PlayerRole {
  const playerPos = playerPositions[playerIndex];
  const distFromCentroid = Math.hypot(
    playerPos[0] - teamCentroid[0],
    playerPos[1] - teamCentroid[1]
  );

  const xPosition = playerPos[0];
  const yPosition = playerPos[1];

  // Determine role based on position
  if (xPosition < 20) {
    return 'Sweeper Keeper';
  } else if (xPosition < 35 && Math.abs(yPosition - 34) < 15) {
    return 'Ball-Winning Defender';
  } else if (xPosition < 65 && Math.abs(yPosition - 34) < 20) {
    return 'Box-to-Box Midfielder';
  } else if (xPosition > 65 && Math.abs(yPosition - 34) > 15) {
    return 'Inverted Winger';
  } else {
    return 'Target Forward';
  }
}

/**
 * Classify team playing style based on spatial distribution
 */
export function classifyPlayingStyle(players: PlayerData[]): PlayingStyle {
  const avgX = players.reduce((sum, p) => sum + p.x, 0) / players.length;
  const avgActivity = players.reduce((sum, p) => sum + p.activity, 0) / players.length;

  if (avgActivity > 7 && avgX > 60) {
    return 'Gegenpressing';
  } else if (avgX < 40) {
    return 'Park the Bus';
  } else if (avgX > 50 && avgActivity < 5) {
    return 'Tiki-Taka';
  } else {
    return 'Tactical Hybrid';
  }
}

/**
 * Determine pressing zone based on team positioning
 */
export function determinPressingZone(players: PlayerData[]): PressingZone {
  const avgX = players.reduce((sum, p) => sum + p.x, 0) / players.length;

  if (avgX > 70) {
    return 'High-Press Final Third';
  } else if (avgX > 40) {
    return 'Mid-Block';
  } else {
    return 'Low-Block Defensive Third';
  }
}

/**
 * Calculate team compactness (0-10 scale)
 */
export function calculateCompactness(players: PlayerData[]): number {
  if (players.length === 0) return 0;

  const centroid = [
    players.reduce((sum, p) => sum + p.x, 0) / players.length,
    players.reduce((sum, p) => sum + p.y, 0) / players.length
  ];

  const avgDistance = players.reduce((sum, p) => {
    return sum + Math.hypot(p.x - centroid[0], p.y - centroid[1]);
  }, 0) / players.length;

  // Normalize to 0-10 scale (lower distance = higher compactness)
  return Math.max(0, Math.min(10, 10 - (avgDistance / 15)));
}

/**
 * Calculate pitch width utilization (0-10 scale)
 */
export function calculateWidth(players: PlayerData[]): number {
  if (players.length === 0) return 0;

  const yPositions = players.map(p => p.y);
  const minY = Math.min(...yPositions);
  const maxY = Math.max(...yPositions);
  const width = maxY - minY;

  // Normalize to 0-10 scale (max pitch width is ~68)
  return Math.min(10, (width / 68) * 10);
}

/**
 * Detect tactical weaknesses
 */
export function detectWeaknesses(teamA: PlayerData[], teamB: PlayerData[]): TacticalWeakness[] {
  const weaknesses: TacticalWeakness[] = [];

  const teamAWidth = calculateWidth(teamA);
  const teamBWidth = calculateWidth(teamB);

  if (Math.abs(teamAWidth - teamBWidth) > 5) {
    weaknesses.push('Narrow Structural Bias');
  }

  const teamAAvgX = teamA.reduce((sum, p) => sum + p.x, 0) / teamA.length;
  if (teamAAvgX > 75) {
    weaknesses.push('Counter-Attack Vulnerability');
  }

  const compactness = calculateCompactness(teamA);
  if (compactness < 4) {
    weaknesses.push('Broken Defensive Lines');
  }

  return weaknesses;
}

/**
 * Generate tactical recovery protocol for detected flaw
 */
export function generateRecoveryProtocol(
  team: 'A' | 'B',
  weakness: TacticalWeakness,
  zone: string
): RecoveryProtocol {
  const protocols: Record<TacticalWeakness, string> = {
    'Narrow Structural Bias': 'Instruct fullbacks to hold the touchline and maintain width. Shift midfielders to support wing play.',
    'Counter-Attack Vulnerability': 'Deploy a deeper defensive line. Add a defensive midfielder to cover transitions.',
    'Broken Defensive Lines': 'Implement a structured pressing trigger. Ensure midfield covers defensive gaps during transitions.'
  };

  return {
    team,
    issue: weakness,
    zone,
    recommendation: protocols[weakness],
    formationAdjustment: weakness === 'Narrow Structural Bias' ? '4-3-3 to 4-2-4' : undefined
  };
}

/**
 * Perform comprehensive match analysis
 */
export function analyzeMatch(
  teamAPlayers: PlayerData[],
  teamBPlayers: PlayerData[]
): AnalysisResult {
  const styleA = classifyPlayingStyle(teamAPlayers);
  const styleB = classifyPlayingStyle(teamBPlayers);
  const pressingA = determinPressingZone(teamAPlayers);
  const pressingB = determinPressingZone(teamBPlayers);
  const compactnessA = calculateCompactness(teamAPlayers);
  const compactnessB = calculateCompactness(teamBPlayers);
  const widthA = calculateWidth(teamAPlayers);
  const widthB = calculateWidth(teamBPlayers);

  const weaknessesA = detectWeaknesses(teamAPlayers, teamBPlayers);
  const weaknessesB = detectWeaknesses(teamBPlayers, teamAPlayers);

  const recoveryProtocols: RecoveryProtocol[] = [
    ...weaknessesA.map(w => generateRecoveryProtocol('A', w, 'Central Area')),
    ...weaknessesB.map(w => generateRecoveryProtocol('B', w, 'Central Area'))
  ];

  const matchupVerdict = compactnessA > compactnessB
    ? `Team A dominates structurally with superior ${styleA} execution and ${pressingA} intensity.`
    : `Team B maintains structural control through disciplined ${styleB} and ${pressingB} positioning.`;

  return {
    teamA: {
      team: 'A',
      playingStyle: styleA,
      pressingZone: pressingA,
      compactness: compactnessA,
      width: widthA,
      cohesion: 'Elite Unit Cohesion',
      players: teamAPlayers,
      weaknesses: weaknessesA,
      strengths: ['Spatial Dominance', 'Pressing Intensity']
    },
    teamB: {
      team: 'B',
      playingStyle: styleB,
      pressingZone: pressingB,
      compactness: compactnessB,
      width: widthB,
      cohesion: 'Solid Defensive Block',
      players: teamBPlayers,
      weaknesses: weaknessesB,
      strengths: ['Structural Discipline']
    },
    matchupVerdict,
    recoveryProtocols,
    coachingCommentary: `${matchupVerdict} ${styleA} requires constant pressure, while ${styleB} relies on defensive organization. Key tactical battle occurs in the ${pressingA.toLowerCase()}.`
  };
}
