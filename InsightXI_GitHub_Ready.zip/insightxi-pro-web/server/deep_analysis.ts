/**
 * Deep Player & Tactical Analysis Engine
 * Provides detailed player-by-player insights, exact positioning analysis, and comprehensive tactical breakdown
 */

export interface DetailedPlayerAnalysis {
  playerId: number;
  team: 'A' | 'B';
  role: string;
  position: {
    x: number;
    y: number;
    zone: string; // Left Wing, Center, Right Wing, etc.
  };
  activity: {
    score: number; // 0-10
    description: string; // "High Intensity", "Moderate", "Defensive"
  };
  strengths: string[];
  weaknesses: string[];
  keyResponsibilities: string[];
  performanceMetrics: {
    pressureApplied: number; // 0-10
    defensiveContribution: number; // 0-10
    passingAccuracy: number; // 0-10
    ballRecovery: number; // 0-10
  };
  matchupAnalysis: {
    opponent: number; // opposing player ID
    advantage: string; // "Dominant", "Balanced", "Struggling"
    reason: string;
  };
}

export interface TeamTacticalBreakdown {
  team: 'A' | 'B';
  overallStyle: string;
  formationDetected: string; // "4-3-3", "5-2-3", etc.
  defensiveApproach: string;
  offensiveApproach: string;
  midfielFieldControl: string;
  transitionStrategy: string;
  setPlayTendency: string;
  pressureProfile: {
    zone: string;
    intensity: number; // 0-10
    effectiveness: number; // 0-10
  };
  vulnerabilities: {
    zone: string;
    issue: string;
    severity: number; // 0-10
    exploitableBy: string;
  }[];
  strengths: {
    area: string;
    description: string;
    impact: number; // 0-10
  }[];
}

export interface MatchDynamics {
  dominantTeam: 'A' | 'B' | 'Balanced';
  dominanceReason: string;
  keyBattles: {
    area: string;
    teamA_advantage: number; // -10 to +10
    description: string;
  }[];
  criticalMoments: {
    time: string;
    event: string;
    impact: string;
  }[];
  predictedOutcome: string;
}

/**
 * Analyze individual player performance in detail
 */
export function analyzePlayerDeep(
  playerId: number,
  team: 'A' | 'B',
  position: [number, number],
  teamCentroid: [number, number],
  allPlayers: Array<{ id: number; team: 'A' | 'B'; x: number; y: number }>
): DetailedPlayerAnalysis {
  const role = determinePlayerRole(position, team);
  const zone = determineZone(position);
  const activity = calculateActivityScore(position, teamCentroid);

  // Find opposing player closest to this player
  const opponents = allPlayers.filter(p => p.team !== team);
  let closestOpponent = opponents[0];
  let minDist = Infinity;

  opponents.forEach(opp => {
    const dist = Math.hypot(position[0] - opp.x, position[1] - opp.y);
    if (dist < minDist) {
      minDist = dist;
      closestOpponent = opp;
    }
  });

  const strengths = getPlayerStrengths(role, activity);
  const weaknesses = getPlayerWeaknesses(role, activity);
  const responsibilities = getPlayerResponsibilities(role);

  return {
    playerId,
    team,
    role,
    position: {
      x: position[0],
      y: position[1],
      zone
    },
    activity: {
      score: activity,
      description: activity > 7 ? 'High Intensity' : activity > 4 ? 'Moderate' : 'Defensive'
    },
    strengths,
    weaknesses,
    keyResponsibilities: responsibilities,
    performanceMetrics: {
      pressureApplied: calculatePressure(role, activity),
      defensiveContribution: calculateDefense(role, activity),
      passingAccuracy: calculatePassing(role, activity),
      ballRecovery: calculateRecovery(role, activity)
    },
    matchupAnalysis: {
      opponent: closestOpponent?.id || 0,
      advantage: minDist < 10 ? 'Struggling' : minDist < 20 ? 'Balanced' : 'Dominant',
      reason: minDist < 10 ? 'Closely marked by opponent' : 'Good spacing from opposition'
    }
  };
}

/**
 * Determine player's tactical zone
 */
function determineZone(position: [number, number]): string {
  const x = position[0];
  const y = position[1];

  let xZone = '';
  if (x < 25) xZone = 'Defensive Third';
  else if (x < 65) xZone = 'Midfield';
  else xZone = 'Attacking Third';

  let yZone = '';
  if (y < 17) yZone = 'Left Wing';
  else if (y < 34) yZone = 'Left Center';
  else if (y < 51) yZone = 'Center';
  else if (y < 68) yZone = 'Right Center';
  else yZone = 'Right Wing';

  return `${xZone} - ${yZone}`;
}

/**
 * Calculate player activity score based on distance from team centroid
 */
function calculateActivityScore(position: [number, number], centroid: [number, number]): number {
  const dist = Math.hypot(position[0] - centroid[0], position[1] - centroid[1]);
  // Higher distance from centroid = higher activity (more spread out = more attacking/aggressive)
  return Math.min(10, (dist / 20) * 10);
}

/**
 * Determine player role based on position
 */
function determinePlayerRole(position: [number, number], team: 'A' | 'B'): string {
  const x = position[0];
  const y = position[1];

  if (x < 15) return 'Sweeper Keeper';
  if (x < 35 && Math.abs(y - 34) < 20) return 'Ball-Winning Defender';
  if (x < 50 && Math.abs(y - 34) < 25) return 'Box-to-Box Midfielder';
  if (x > 60 && Math.abs(y - 34) > 15) return 'Inverted Winger';
  return 'Target Forward';
}

/**
 * Get player strengths based on role and activity
 */
function getPlayerStrengths(role: string, activity: number): string[] {
  const strengths: Record<string, string[]> = {
    'Sweeper Keeper': ['Distribution', 'Positioning', 'Command of Box'],
    'Ball-Winning Defender': ['Tackling', 'Interceptions', 'Physical Presence'],
    'Box-to-Box Midfielder': ['Versatility', 'Work Rate', 'Transition Play'],
    'Inverted Winger': ['Dribbling', 'Creativity', 'Cutting Inside'],
    'Target Forward': ['Positioning', 'Finishing', 'Hold-up Play']
  };

  let baseStrengths = strengths[role] || ['Positioning'];
  if (activity > 7) baseStrengths.push('High Intensity');
  return baseStrengths;
}

/**
 * Get player weaknesses based on role and activity
 */
function getPlayerWeaknesses(role: string, activity: number): string[] {
  const weaknesses: Record<string, string[]> = {
    'Sweeper Keeper': ['Limited Sweeping', 'Distribution Risk'],
    'Ball-Winning Defender': ['Positioning Gaps', 'Aerial Weakness'],
    'Box-to-Box Midfielder': ['Defensive Gaps', 'Inconsistency'],
    'Inverted Winger': ['Defensive Liability', 'Crossing Weakness'],
    'Target Forward': ['Work Rate', 'Pressing Intensity']
  };

  let baseWeaknesses = weaknesses[role] || ['Consistency'];
  if (activity < 3) baseWeaknesses.push('Low Engagement');
  return baseWeaknesses;
}

/**
 * Get player key responsibilities
 */
function getPlayerResponsibilities(role: string): string[] {
  const responsibilities: Record<string, string[]> = {
    'Sweeper Keeper': ['Distribute from back', 'Command penalty area', 'Organize defense'],
    'Ball-Winning Defender': ['Win possession', 'Block shots', 'Cover fullbacks'],
    'Box-to-Box Midfielder': ['Connect defense to attack', 'Box-to-box runs', 'Transition play'],
    'Inverted Winger': ['Create chances', 'Dribble inside', 'Cut back passes'],
    'Target Forward': ['Hold possession', 'Finish chances', 'Link-up play']
  };

  return responsibilities[role] || ['Support team play'];
}

/**
 * Calculate pressure applied by player
 */
function calculatePressure(role: string, activity: number): number {
  const roleBase: Record<string, number> = {
    'Sweeper Keeper': 2,
    'Ball-Winning Defender': 8,
    'Box-to-Box Midfielder': 6,
    'Inverted Winger': 5,
    'Target Forward': 4
  };
  return Math.min(10, (roleBase[role] || 5) + (activity / 2));
}

/**
 * Calculate defensive contribution
 */
function calculateDefense(role: string, activity: number): number {
  const roleBase: Record<string, number> = {
    'Sweeper Keeper': 9,
    'Ball-Winning Defender': 9,
    'Box-to-Box Midfielder': 6,
    'Inverted Winger': 3,
    'Target Forward': 2
  };
  return roleBase[role] || 5;
}

/**
 * Calculate passing accuracy
 */
function calculatePassing(role: string, activity: number): number {
  const roleBase: Record<string, number> = {
    'Sweeper Keeper': 7,
    'Ball-Winning Defender': 6,
    'Box-to-Box Midfielder': 8,
    'Inverted Winger': 7,
    'Target Forward': 6
  };
  return roleBase[role] || 6;
}

/**
 * Calculate ball recovery
 */
function calculateRecovery(role: string, activity: number): number {
  const roleBase: Record<string, number> = {
    'Sweeper Keeper': 8,
    'Ball-Winning Defender': 9,
    'Box-to-Box Midfielder': 7,
    'Inverted Winger': 4,
    'Target Forward': 3
  };
  return roleBase[role] || 5;
}

/**
 * Generate comprehensive team tactical breakdown
 */
export function generateTeamBreakdown(
  players: DetailedPlayerAnalysis[],
  teamStyle: string,
  pressingZone: string
): TeamTacticalBreakdown {
  const formationDetected = detectFormation(players);
  
  return {
    team: players[0].team,
    overallStyle: teamStyle,
    formationDetected,
    defensiveApproach: getDefensiveApproach(teamStyle, pressingZone),
    offensiveApproach: getOffensiveApproach(teamStyle),
    midfielFieldControl: getMidfieldControl(players),
    transitionStrategy: getTransitionStrategy(teamStyle),
    setPlayTendency: getSetPlayTendency(teamStyle),
    pressureProfile: {
      zone: pressingZone,
      intensity: calculateTeamPressure(players),
      effectiveness: calculatePressureEffectiveness(players)
    },
    vulnerabilities: identifyVulnerabilities(players, teamStyle),
    strengths: identifyStrengths(players, teamStyle)
  };
}

/**
 * Detect formation from player positions
 */
function detectFormation(players: DetailedPlayerAnalysis[]): string {
  const defenders = players.filter(p => p.role.includes('Defender') || p.role.includes('Keeper')).length;
  const midfielders = players.filter(p => p.role.includes('Midfielder')).length;
  const forwards = players.filter(p => p.role.includes('Forward') || p.role.includes('Winger')).length;

  return `${defenders}-${midfielders}-${forwards}`;
}

/**
 * Get defensive approach based on style
 */
function getDefensiveApproach(style: string, zone: string): string {
  if (style === 'Gegenpressing') return 'High pressing with aggressive man-marking';
  if (style === 'Park the Bus') return 'Deep defensive block with compact shape';
  if (style === 'Tiki-Taka') return 'Possession-based defense through ball control';
  return 'Balanced defensive approach';
}

/**
 * Get offensive approach
 */
function getOffensiveApproach(style: string): string {
  if (style === 'Gegenpressing') return 'Quick transitions to counter-attack';
  if (style === 'Park the Bus') return 'Direct long balls and set pieces';
  if (style === 'Tiki-Taka') return 'Intricate passing and positional play';
  return 'Balanced attacking approach';
}

/**
 * Get midfield control assessment
 */
function getMidfieldControl(players: DetailedPlayerAnalysis[]): string {
  const midfielders = players.filter(p => p.role.includes('Midfielder'));
  const avgActivity = midfielders.reduce((sum, p) => sum + p.activity.score, 0) / midfielders.length;

  if (avgActivity > 7) return 'Dominant midfield control';
  if (avgActivity > 5) return 'Balanced midfield battle';
  return 'Struggling for midfield possession';
}

/**
 * Get transition strategy
 */
function getTransitionStrategy(style: string): string {
  if (style === 'Gegenpressing') return 'Immediate counter-pressing and rapid transitions';
  if (style === 'Park the Bus') return 'Organized defensive shape with quick breaks';
  if (style === 'Tiki-Taka') return 'Controlled possession transitions';
  return 'Flexible transition approach';
}

/**
 * Get set play tendency
 */
function getSetPlayTendency(style: string): string {
  if (style === 'Park the Bus') return 'Defensive set pieces, dangerous on corners';
  if (style === 'Gegenpressing') return 'Quick restart to maintain pressure';
  return 'Standard set play execution';
}

/**
 * Calculate team pressure
 */
function calculateTeamPressure(players: DetailedPlayerAnalysis[]): number {
  const avgPressure = players.reduce((sum, p) => sum + p.performanceMetrics.pressureApplied, 0) / players.length;
  return Math.min(10, avgPressure);
}

/**
 * Calculate pressure effectiveness
 */
function calculatePressureEffectiveness(players: DetailedPlayerAnalysis[]): number {
  const avgRecovery = players.reduce((sum, p) => sum + p.performanceMetrics.ballRecovery, 0) / players.length;
  return Math.min(10, avgRecovery);
}

/**
 * Identify team vulnerabilities
 */
function identifyVulnerabilities(players: DetailedPlayerAnalysis[], style: string): Array<{zone: string; issue: string; severity: number; exploitableBy: string}> {
  const vulnerabilities = [];

  const defenders = players.filter(p => p.role.includes('Defender'));
  if (defenders.length < 4) {
    vulnerabilities.push({
      zone: 'Defense',
      issue: 'Insufficient defensive coverage',
      severity: 8,
      exploitableBy: 'Direct attacking play'
    });
  }

  const wingPlayers = players.filter(p => p.position.zone.includes('Wing'));
  if (wingPlayers.length < 2) {
    vulnerabilities.push({
      zone: 'Wings',
      issue: 'Weak flank coverage',
      severity: 6,
      exploitableBy: 'Wide play and crosses'
    });
  }

  if (style === 'Gegenpressing') {
    vulnerabilities.push({
      zone: 'Counter-attacks',
      issue: 'Exposed to quick transitions',
      severity: 7,
      exploitableBy: 'Long balls and fast breaks'
    });
  }

  return vulnerabilities;
}

/**
 * Identify team strengths
 */
function identifyStrengths(players: DetailedPlayerAnalysis[], style: string): Array<{area: string; description: string; impact: number}> {
  const strengths = [];

  const avgActivity = players.reduce((sum, p) => sum + p.activity.score, 0) / players.length;
  if (avgActivity > 6) {
    strengths.push({
      area: 'Intensity',
      description: 'High pressing and aggressive play throughout the pitch',
      impact: 8
    });
  }

  const avgPassing = players.reduce((sum, p) => sum + p.performanceMetrics.passingAccuracy, 0) / players.length;
  if (avgPassing > 7) {
    strengths.push({
      area: 'Possession',
      description: 'Excellent ball control and passing accuracy',
      impact: 8
    });
  }

  if (style === 'Park the Bus') {
    strengths.push({
      area: 'Defense',
      description: 'Compact defensive shape and organization',
      impact: 9
    });
  }

  return strengths;
}

/**
 * Analyze match dynamics and predict outcome
 */
export function analyzeMatchDynamics(
  teamA: TeamTacticalBreakdown,
  teamB: TeamTacticalBreakdown,
  allPlayers: DetailedPlayerAnalysis[]
): MatchDynamics {
  const teamAAvgPressure = allPlayers
    .filter(p => p.team === 'A')
    .reduce((sum, p) => sum + p.performanceMetrics.pressureApplied, 0) / 
    allPlayers.filter(p => p.team === 'A').length;

  const teamBAvgPressure = allPlayers
    .filter(p => p.team === 'B')
    .reduce((sum, p) => sum + p.performanceMetrics.pressureApplied, 0) / 
    allPlayers.filter(p => p.team === 'B').length;

  const dominantTeam = teamAAvgPressure > teamBAvgPressure + 1 ? 'A' : 
                       teamBAvgPressure > teamAAvgPressure + 1 ? 'B' : 'Balanced';

  return {
    dominantTeam,
    dominanceReason: dominantTeam === 'A' ? 'Superior pressing intensity and midfield control' :
                     dominantTeam === 'B' ? 'Solid defensive organization and counter-attack threat' :
                     'Evenly matched tactical battle',
    keyBattles: [
      {
        area: 'Midfield',
        teamA_advantage: teamAAvgPressure - teamBAvgPressure,
        description: 'Central midfield battle determines possession and transitions'
      },
      {
        area: 'Flanks',
        teamA_advantage: (Math.random() - 0.5) * 10,
        description: 'Wing play and fullback positioning critical'
      }
    ],
    criticalMoments: [
      {
        time: '0-15 min',
        event: 'Opening intensity and tactical setup',
        impact: 'Sets tone for the match'
      },
      {
        time: '35-45 min',
        event: 'Late first half momentum shifts',
        impact: 'Can swing match before halftime'
      }
    ],
    predictedOutcome: dominantTeam === 'A' ? 'Team A likely to control the match and create more chances' :
                      dominantTeam === 'B' ? 'Team B likely to frustrate Team A and exploit set pieces' :
                      'Competitive match with multiple possible outcomes'
  };
}
