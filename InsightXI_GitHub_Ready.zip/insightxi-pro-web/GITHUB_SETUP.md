# InsightXI Elite - GitHub Setup & Streamlit Cloud Deployment Guide

## 🚀 Quick Start

This is a production-ready AI-powered football tactical analysis platform designed for **one-click deployment on Streamlit Cloud**.

### What You Get

- **Elite Dark-Themed Dashboard**: Professional UI with gradient title and metric cards
- **Deep AI Analysis**: Player-by-player insights, tactical breakdowns, playing style detection
- **Dual-Team Intelligence**: Automatic Team A/B separation and comparative analysis
- **Recovery Protocols**: Specific tactical recommendations for detected flaws
- **Batch Processing**: Analyze multiple match clips in one session
- **Analysis History**: Track tactical evolution across a season

---

## 📦 File Structure

```
InsightXI/
├── streamlit_app.py              # Main entry point for Streamlit Cloud
├── requirements.txt               # Python dependencies
├── .streamlit/
│   └── config.toml               # Streamlit configuration
├── server/
│   ├── analysis.ts               # Core AI analysis engine
│   ├── deep_analysis.ts          # Player-by-player deep analysis
│   └── ...                       # Additional backend files
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   └── Dashboard.tsx     # Main dashboard component
│   │   ├── components/
│   │   │   └── TacticalPitch.tsx # Pitch visualization
│   │   └── index.css             # Elite dark theme styling
│   └── ...
├── GITHUB_SETUP.md               # This file
└── README.md                     # Project documentation
```

---

## 🔧 Setup Instructions

### Step 1: Create a GitHub Repository

1. Go to [GitHub](https://github.com/new)
2. Create a new repository named `InsightXI`
3. Choose **Private** (recommended for proprietary AI)
4. Do NOT initialize with README/gitignore/license

### Step 2: Clone and Add Files

```bash
# Clone your new repository
git clone https://github.com/YOUR_USERNAME/InsightXI.git
cd InsightXI

# Copy all project files into this directory
# (Drag and drop all files from the package)

# Add all files to git
git add .

# Commit
git commit -m "Initial InsightXI Elite setup"

# Push to GitHub
git push origin main
```

### Step 3: Deploy to Streamlit Cloud

1. Go to [Streamlit Cloud](https://share.streamlit.io/)
2. Click **"Create app"**
3. Select your GitHub repository: `YOUR_USERNAME/InsightXI`
4. Set **Main file path**: `streamlit_app.py`
5. Click **"Deploy"**

Your app will be live in 2-3 minutes at: `https://insightxi-YOUR_USERNAME.streamlit.app`

---

## 🎯 Key Features Explained

### 1. Elite Dark Theme
- Deep purple/blue background with green accents
- Gradient title with professional styling
- Responsive design for all screen sizes

### 2. Video Upload & Analysis
- Drag-and-drop interface for match footage
- Batch processing support (multiple clips)
- Real-time analysis progress

### 3. Deep AI Analysis

#### Playing Styles Detected
- **Gegenpressing**: High-intensity pressing with quick transitions
- **Park the Bus**: Defensive organization with counter-attack focus
- **Tiki-Taka**: Possession-based control through passing
- **Tactical Hybrid**: Balanced approach

#### Player Roles Identified
- **Sweeper Keeper**: Distribution and command of box
- **Ball-Winning Defender**: Tackling and interceptions
- **Box-to-Box Midfielder**: Versatility and work rate
- **Inverted Winger**: Dribbling and creativity
- **Target Forward**: Positioning and finishing

#### Pressing Zones Mapped
- **High-Press Final Third**: Aggressive attacking pressure
- **Mid-Block**: Balanced defensive positioning
- **Low-Block Defensive Third**: Deep defensive setup

#### Tactical Weaknesses Detected
- **Narrow Structural Bias**: Insufficient pitch width
- **Counter-Attack Vulnerability**: Exposed to quick transitions
- **Broken Defensive Lines**: Large gaps in defensive shape

### 4. Recovery Protocols
Each detected weakness generates specific tactical recommendations:
- Formation adjustments
- Positioning changes
- Player role modifications
- Pressing strategy updates

### 5. Analysis History
- Track all past analyses
- Compare tactical evolution
- Export reports

---

## 🔐 Environment Variables (Optional)

If you want to add database or API features later:

1. In Streamlit Cloud dashboard, click **"Secrets"**
2. Add any required secrets in TOML format:

```toml
# Example
DATABASE_URL = "your_database_connection_string"
API_KEY = "your_api_key"
```

---

## 📊 Using the Application

### Single Match Analysis
1. Upload a match video (MP4, MOV, AVI)
2. Click "Start Deep Analysis"
3. View comprehensive tactical breakdown:
   - Matchup verdict
   - Team metrics (compactness, width, pressing zone)
   - Player-by-player analysis
   - Detected weaknesses with recovery protocols
   - Coaching commentary

### Batch Analysis
1. Upload multiple video clips (1st half, 2nd half, etc.)
2. Click "Analyze All Clips"
3. Get combined analysis showing tactical evolution across the match

### Analysis History
- View all past analyses
- Compare tactical approaches
- Track improvements over time

---

## 🎨 Customization

### Change Theme Colors
Edit `client/src/index.css`:
```css
.dark {
  --primary: oklch(0.45 0.15 142);  /* Green accent */
  --background: oklch(0.08 0.08 262);  /* Dark background */
  /* ... more colors ... */
}
```

### Modify AI Analysis Parameters
Edit `server/analysis.ts` and `server/deep_analysis.ts`:
- Adjust role detection thresholds
- Customize weakness detection logic
- Modify recovery protocol recommendations

---

## 🚨 Troubleshooting

### "streamlit_app.py not found"
Make sure `streamlit_app.py` is in the **root directory** of your repository, not in a subfolder.

### Slow video processing
- Use the "YOLOv8n (Fast)" model in the sidebar for quicker analysis
- Streamlit Cloud has limited resources; videos >100MB may timeout

### App crashes on deployment
- Check that all files are properly committed to GitHub
- Verify `requirements.txt` includes all dependencies
- Check Streamlit Cloud logs for error messages

---

## 📝 Dependencies

All required packages are listed in `requirements.txt`:
- `streamlit` - Web framework
- `opencv-python` - Video processing
- `numpy` - Numerical computations
- `pandas` - Data manipulation
- `matplotlib` - Visualization

---

## 🔄 Updates & Maintenance

To update your deployment:

1. Make changes locally
2. Commit and push to GitHub:
   ```bash
   git add .
   git commit -m "Update AI analysis logic"
   git push origin main
   ```
3. Streamlit Cloud automatically redeploys (usually within 1-2 minutes)

---

## 📞 Support

For issues or questions:
1. Check the [Streamlit documentation](https://docs.streamlit.io/)
2. Review the `README.md` for detailed feature documentation
3. Check GitHub issues for similar problems

---

## 🎯 Next Steps

1. **Deploy to Streamlit Cloud** (follow Step 3 above)
2. **Test with sample match footage**
3. **Customize AI parameters** for your specific needs
4. **Add database integration** for analysis persistence
5. **Integrate LLM** for natural-language coaching commentary

---

**InsightXI Elite © 2026** | Autonomous Tactical Intelligence Platform
