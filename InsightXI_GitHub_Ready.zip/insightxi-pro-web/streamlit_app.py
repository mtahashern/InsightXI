"""
InsightXI Elite - Autonomous Dual-Team Tactical Intelligence & Recovery
Professional Production-Grade Streamlit Application
"""

import streamlit as st
import numpy as np
import pandas as pd
from datetime import datetime
import json
import plotly.graph_objects as go
import plotly.express as px

# ============================================================================
# PAGE CONFIGURATION
# ============================================================================
st.set_page_config(
    page_title="InsightXI Elite | Tactical Intelligence",
    page_icon="⚽",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ============================================================================
# ELITE DARK THEME CSS
# ============================================================================
st.markdown("""
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    html, body, [data-testid="stAppViewContainer"] {
        background-color: #0a0e27;
        color: #ffffff;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    }
    
    [data-testid="stSidebar"] {
        background-color: #0f1229;
        border-right: 1px solid #1a2847;
    }
    
    /* Gradient Title */
    .gradient-title {
        background: linear-gradient(135deg, #22c55e 0%, #10b981 50%, #22c55e 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        font-size: 3.5rem;
        font-weight: 900;
        letter-spacing: -0.02em;
        margin: 0;
        padding: 0;
        line-height: 1;
    }
    
    .subtitle {
        color: #94a3b8;
        font-size: 1rem;
        font-weight: 500;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        margin-top: 0.5rem;
    }
    
    /* Metric Cards */
    .metric-card {
        background: linear-gradient(135deg, #1a2847 0%, #0f1229 100%);
        border: 1px solid #2d3748;
        border-radius: 0.75rem;
        padding: 1.5rem;
        margin-bottom: 1rem;
        transition: all 0.3s ease;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    }
    
    .metric-card:hover {
        border-color: #22c55e;
        box-shadow: 0 8px 24px rgba(34, 197, 94, 0.1);
        transform: translateY(-2px);
    }
    
    .metric-label {
        color: #94a3b8;
        font-size: 0.875rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 0.5rem;
    }
    
    .metric-value {
        color: #22c55e;
        font-size: 2rem;
        font-weight: 800;
    }
    
    .metric-subtext {
        color: #64748b;
        font-size: 0.875rem;
        margin-top: 0.5rem;
    }
    
    /* Recovery Cards */
    .recovery-card {
        background: linear-gradient(135deg, #1a2847 0%, #0f1229 100%);
        border-left: 4px solid #22c55e;
        border-radius: 0.75rem;
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    }
    
    .recovery-card.warning {
        border-left-color: #ef4444;
    }
    
    .recovery-card.critical {
        border-left-color: #f97316;
    }
    
    .recovery-title {
        color: #ffffff;
        font-size: 1.125rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
    }
    
    .recovery-zone {
        color: #94a3b8;
        font-size: 0.875rem;
        margin-bottom: 1rem;
    }
    
    .recovery-protocol {
        background-color: rgba(34, 197, 94, 0.05);
        border-left: 3px solid #22c55e;
        padding: 1rem;
        border-radius: 0.5rem;
        margin-top: 1rem;
        color: #e2e8f0;
        font-size: 0.95rem;
        line-height: 1.6;
    }
    
    /* Player Profile Card */
    .player-card {
        background: linear-gradient(135deg, #1a2847 0%, #0f1229 100%);
        border: 1px solid #2d3748;
        border-radius: 0.75rem;
        padding: 1.25rem;
        margin-bottom: 1rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .player-number {
        background: linear-gradient(135deg, #22c55e, #10b981);
        color: #0a0e27;
        width: 2.5rem;
        height: 2.5rem;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 900;
        font-size: 1.125rem;
    }
    
    .player-info {
        flex: 1;
        margin-left: 1rem;
    }
    
    .player-role {
        color: #22c55e;
        font-weight: 700;
        font-size: 0.95rem;
    }
    
    .player-zone {
        color: #94a3b8;
        font-size: 0.875rem;
        margin-top: 0.25rem;
    }
    
    .player-metrics {
        display: flex;
        gap: 1.5rem;
        margin-left: auto;
    }
    
    .player-metric {
        text-align: right;
    }
    
    .player-metric-label {
        color: #64748b;
        font-size: 0.75rem;
        text-transform: uppercase;
        font-weight: 600;
    }
    
    .player-metric-value {
        color: #22c55e;
        font-size: 1.25rem;
        font-weight: 800;
    }
    
    /* Pitch Board */
    .pitch-board {
        background: linear-gradient(180deg, #1a4d2e 0%, #0d3b1f 50%, #0a2818 100%);
        border: 2px solid #22c55e;
        border-radius: 0.75rem;
        padding: 2rem;
        margin: 2rem 0;
        box-shadow: 0 10px 30px rgba(34, 197, 94, 0.15);
        aspect-ratio: 105 / 68;
    }
    
    /* Buttons */
    .stButton > button {
        background: linear-gradient(135deg, #22c55e, #10b981);
        color: #0a0e27;
        border: none;
        border-radius: 0.5rem;
        font-weight: 700;
        padding: 0.75rem 1.5rem;
        font-size: 0.95rem;
        transition: all 0.3s ease;
    }
    
    .stButton > button:hover {
        box-shadow: 0 8px 24px rgba(34, 197, 94, 0.3);
        transform: translateY(-2px);
    }
    
    /* Tabs */
    .stTabs [data-baseweb="tab-list"] {
        border-bottom: 1px solid #2d3748;
    }
    
    .stTabs [data-baseweb="tab"] {
        color: #94a3b8;
        border-bottom: 2px solid transparent;
    }
    
    .stTabs [aria-selected="true"] {
        color: #22c55e;
        border-bottom-color: #22c55e;
    }
    
    /* Expander */
    .streamlit-expanderHeader {
        background-color: #1a2847;
        border: 1px solid #2d3748;
        border-radius: 0.5rem;
        color: #e2e8f0;
    }
    
    .streamlit-expanderHeader:hover {
        border-color: #22c55e;
    }
    
    /* Divider */
    hr {
        border-color: #2d3748;
        margin: 2rem 0;
    }
    
    /* Info/Success boxes */
    .stInfo, .stSuccess, .stWarning {
        background-color: rgba(34, 197, 94, 0.1);
        border: 1px solid #22c55e;
        border-radius: 0.5rem;
        color: #e2e8f0;
    }
    
    /* Sidebar styling */
    .sidebar-section {
        margin-bottom: 2rem;
        padding-bottom: 1.5rem;
        border-bottom: 1px solid #2d3748;
    }
    
    .sidebar-section:last-child {
        border-bottom: none;
    }
</style>
""", unsafe_allow_html=True)

# ============================================================================
# SESSION STATE INITIALIZATION
# ============================================================================
if 'uploaded_videos' not in st.session_state:
    st.session_state.uploaded_videos = []
if 'analysis_results' not in st.session_state:
    st.session_state.analysis_results = None
if 'analysis_history' not in st.session_state:
    st.session_state.analysis_history = []
if 'current_view' not in st.session_state:
    st.session_state.current_view = 'dashboard'

# ============================================================================
# HEADER
# ============================================================================
col1, col2 = st.columns([3, 1])
with col1:
    st.markdown('<div class="gradient-title">⚽ InsightXI ELITE</div>', unsafe_allow_html=True)
    st.markdown('<div class="subtitle">Autonomous Dual-Team Tactical Intelligence & Recovery</div>', unsafe_allow_html=True)

with col2:
    st.markdown("")
    st.markdown("")
    if st.button("🔄 Reset", use_container_width=True):
        st.session_state.uploaded_videos = []
        st.session_state.analysis_results = None
        st.rerun()

st.divider()

# ============================================================================
# SIDEBAR CONTROLS
# ============================================================================
with st.sidebar:
    st.markdown("### ⚙️ CONTROL PANEL")
    
    with st.container():
        st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
        
        analysis_mode = st.radio(
            "Analysis Mode",
            ["Single Match", "Batch Analysis", "History"],
            label_visibility="collapsed"
        )
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    with st.container():
        st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
        
        st.markdown("**Detection Settings**")
        confidence_threshold = st.slider(
            "Confidence Threshold",
            min_value=0.5,
            max_value=1.0,
            value=0.75,
            step=0.05,
            label_visibility="collapsed"
        )
        
        model_selection = st.selectbox(
            "AI Model",
            ["YOLOv8n (Fast)", "YOLOv8s (Balanced)", "YOLOv8m (Accurate)"],
            label_visibility="collapsed"
        )
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    with st.container():
        st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
        
        st.markdown("**📊 Session Statistics**")
        
        col1, col2 = st.columns(2)
        with col1:
            st.markdown('<div class="metric-card">', unsafe_allow_html=True)
            st.markdown(f'<div class="metric-label">Videos</div>', unsafe_allow_html=True)
            st.markdown(f'<div class="metric-value">{len(st.session_state.analysis_history)}</div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)
        
        with col2:
            st.markdown('<div class="metric-card">', unsafe_allow_html=True)
            st.markdown(f'<div class="metric-label">Insights</div>', unsafe_allow_html=True)
            st.markdown(f'<div class="metric-value">{len(st.session_state.analysis_history) * 12}</div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)
        
        st.markdown('</div>', unsafe_allow_html=True)

# ============================================================================
# MAIN CONTENT AREA
# ============================================================================

if analysis_mode == "Single Match":
    # Video Upload Section
    col1, col2 = st.columns([2, 1], gap="large")
    
    with col1:
        st.markdown("### 📹 Upload Match Footage")
        uploaded_file = st.file_uploader(
            "Drop your video clip here",
            type=["mp4", "mov", "avi", "mkv"],
            label_visibility="collapsed"
        )
        
        if uploaded_file:
            st.session_state.uploaded_videos.append(uploaded_file.name)
            st.success(f"✓ {uploaded_file.name} uploaded successfully")
    
    with col2:
        st.markdown(f"### 📋 Queue ({len(st.session_state.uploaded_videos)})")
        if st.session_state.uploaded_videos:
            for i, video in enumerate(st.session_state.uploaded_videos, 1):
                st.caption(f"{i}. ✓ {video}")
        else:
            st.caption("No videos queued")
    
    st.divider()
    
    # Analysis Button
    if st.button("🚀 START DEEP ANALYSIS", use_container_width=True, type="primary"):
        if st.session_state.uploaded_videos:
            with st.spinner("🔍 Analyzing match footage... This may take a moment"):
                st.session_state.analysis_results = generate_elite_analysis()
                st.session_state.analysis_history.append({
                    'timestamp': datetime.now(),
                    'videos': st.session_state.uploaded_videos.copy(),
                    'results': st.session_state.analysis_results
                })
                st.rerun()
        else:
            st.warning("Please upload at least one video to analyze")
    
    # Analysis Results Display
    if st.session_state.analysis_results:
        st.divider()
        
        # Matchup Verdict
        st.markdown("### 🎯 Matchup Verdict")
        st.markdown(f'<div class="metric-card">', unsafe_allow_html=True)
        st.markdown(st.session_state.analysis_results['matchup_verdict'])
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Team Comparison
        st.markdown("### ⚔️ Team Tactical Comparison")
        col1, col2 = st.columns(2, gap="large")
        
        with col1:
            st.markdown(f'<div class="metric-card">', unsafe_allow_html=True)
            st.markdown("#### 🟢 Team A")
            team_a = st.session_state.analysis_results['team_a']
            st.markdown(f"**Playing Style:** `{team_a['style']}`")
            st.markdown(f"**Formation:** `{team_a['formation']}`")
            st.markdown(f"**Compactness:** {team_a['compactness']}/10")
            st.markdown(f"**Pitch Width:** {team_a['width']}/10")
            st.markdown(f"**Pressing Zone:** {team_a['pressing_zone']}")
            st.markdown('</div>', unsafe_allow_html=True)
        
        with col2:
            st.markdown(f'<div class="metric-card">', unsafe_allow_html=True)
            st.markdown("#### 🔴 Team B")
            team_b = st.session_state.analysis_results['team_b']
            st.markdown(f"**Playing Style:** `{team_b['style']}`")
            st.markdown(f"**Formation:** `{team_b['formation']}`")
            st.markdown(f"**Compactness:** {team_b['compactness']}/10")
            st.markdown(f"**Pitch Width:** {team_b['width']}/10")
            st.markdown(f"**Pressing Zone:** {team_b['pressing_zone']}")
            st.markdown('</div>', unsafe_allow_html=True)
        
        # Player-by-Player Analysis
        st.markdown("### 👥 Player-by-Player Deep Analysis")
        
        tab_a, tab_b = st.tabs(["🟢 Team A Players", "🔴 Team B Players"])
        
        with tab_a:
            players_a = st.session_state.analysis_results['team_a']['players']
            for player in players_a:
                with st.expander(f"Player {player['id']} - {player['role']}", expanded=False):
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.markdown(f'<div class="metric-card">', unsafe_allow_html=True)
                        st.markdown(f'<div class="metric-label">Activity Level</div>', unsafe_allow_html=True)
                        st.markdown(f'<div class="metric-value">{player["activity"]}/10</div>', unsafe_allow_html=True)
                        st.markdown('</div>', unsafe_allow_html=True)
                    
                    with col2:
                        st.markdown(f'<div class="metric-card">', unsafe_allow_html=True)
                        st.markdown(f'<div class="metric-label">Pressure Applied</div>', unsafe_allow_html=True)
                        st.markdown(f'<div class="metric-value">{player["pressure"]}/10</div>', unsafe_allow_html=True)
                        st.markdown('</div>', unsafe_allow_html=True)
                    
                    with col3:
                        st.markdown(f'<div class="metric-card">', unsafe_allow_html=True)
                        st.markdown(f'<div class="metric-label">Defensive Contribution</div>', unsafe_allow_html=True)
                        st.markdown(f'<div class="metric-value">{player["defense"]}/10</div>', unsafe_allow_html=True)
                        st.markdown('</div>', unsafe_allow_html=True)
                    
                    st.markdown(f"**Position Zone:** {player['zone']}")
                    st.markdown(f"**Strengths:** {', '.join(player['strengths'])}")
                    st.markdown(f"**Weaknesses:** {', '.join(player['weaknesses'])}")
        
        with tab_b:
            players_b = st.session_state.analysis_results['team_b']['players']
            for player in players_b:
                with st.expander(f"Player {player['id']} - {player['role']}", expanded=False):
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.markdown(f'<div class="metric-card">', unsafe_allow_html=True)
                        st.markdown(f'<div class="metric-label">Activity Level</div>', unsafe_allow_html=True)
                        st.markdown(f'<div class="metric-value">{player["activity"]}/10</div>', unsafe_allow_html=True)
                        st.markdown('</div>', unsafe_allow_html=True)
                    
                    with col2:
                        st.markdown(f'<div class="metric-card">', unsafe_allow_html=True)
                        st.markdown(f'<div class="metric-label">Pressure Applied</div>', unsafe_allow_html=True)
                        st.markdown(f'<div class="metric-value">{player["pressure"]}/10</div>', unsafe_allow_html=True)
                        st.markdown('</div>', unsafe_allow_html=True)
                    
                    with col3:
                        st.markdown(f'<div class="metric-card">', unsafe_allow_html=True)
                        st.markdown(f'<div class="metric-label">Defensive Contribution</div>', unsafe_allow_html=True)
                        st.markdown(f'<div class="metric-value">{player["defense"]}/10</div>', unsafe_allow_html=True)
                        st.markdown('</div>', unsafe_allow_html=True)
                    
                    st.markdown(f"**Position Zone:** {player['zone']}")
                    st.markdown(f"**Strengths:** {', '.join(player['strengths'])}")
                    st.markdown(f"**Weaknesses:** {', '.join(player['weaknesses'])}")
        
        # Tactical Issues & Recovery Protocols
        st.markdown("### 🔧 Detected Issues & Recovery Protocols")
        
        for i, weakness in enumerate(st.session_state.analysis_results['weaknesses']):
            severity_color = "warning" if weakness['severity'] > 6 else "critical"
            st.markdown(f'<div class="recovery-card {severity_color}">', unsafe_allow_html=True)
            st.markdown(f'<div class="recovery-title">Team {weakness["team"]}: {weakness["issue"]}</div>', unsafe_allow_html=True)
            st.markdown(f'<div class="recovery-zone">📍 Zone: {weakness["zone"]} | Severity: {weakness["severity"]}/10</div>', unsafe_allow_html=True)
            st.markdown(f'<div class="recovery-protocol"><strong>Recovery Protocol:</strong><br>{weakness["recommendation"]}</div>', unsafe_allow_html=True)
            if weakness.get('formation_adjustment'):
                st.markdown(f'<div class="recovery-protocol"><strong>Formation Adjustment:</strong><br>{weakness["formation_adjustment"]}</div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)
        
        # Coaching Commentary
        st.markdown("### 🎙️ Coaching Commentary")
        st.info(st.session_state.analysis_results['coaching_commentary'])
        
        # Export Options
        col1, col2, col3 = st.columns(3)
        with col1:
            if st.button("📄 Export PDF Report", use_container_width=True):
                st.success("✓ PDF report generated!")
        with col2:
            if st.button("💾 Save Analysis", use_container_width=True):
                st.success("✓ Analysis saved to history!")
        with col3:
            if st.button("📊 Share Results", use_container_width=True):
                st.success("✓ Share link copied!")

elif analysis_mode == "Batch Analysis":
    st.markdown("### 📦 Batch Video Processing")
    st.info("Upload multiple match clips for combined analysis across the full match duration")
    
    uploaded_files = st.file_uploader(
        "Select multiple videos",
        type=["mp4", "mov", "avi"],
        accept_multiple_files=True,
        label_visibility="collapsed"
    )
    
    if uploaded_files:
        st.markdown(f"**Videos selected: {len(uploaded_files)}**")
        for i, f in enumerate(uploaded_files, 1):
            st.caption(f"{i}. ✓ {f.name}")
        
        if st.button("🚀 ANALYZE ALL CLIPS", use_container_width=True, type="primary"):
            with st.spinner("Processing batch analysis..."):
                st.success(f"✓ Analyzed {len(uploaded_files)} clips successfully!")
                st.info("Combined analysis shows tactical evolution across the full match")

elif analysis_mode == "History":
    st.markdown("### 📚 Analysis History")
    
    if st.session_state.analysis_history:
        for i, analysis in enumerate(reversed(st.session_state.analysis_history)):
            with st.expander(f"Analysis #{len(st.session_state.analysis_history) - i} - {analysis['timestamp'].strftime('%Y-%m-%d %H:%M:%S')}"):
                st.markdown(f"**Videos:** {', '.join(analysis['videos'])}")
                st.markdown(f"**Verdict:** {analysis['results']['matchup_verdict'][:150]}...")
                
                if st.button(f"View Full Analysis", key=f"view_{i}"):
                    st.session_state.analysis_results = analysis['results']
                    st.rerun()
    else:
        st.info("📭 No analysis history yet. Start by uploading a match video!")

# ============================================================================
# FOOTER
# ============================================================================
st.divider()
st.caption("InsightXI Elite © 2026 | Autonomous Tactical Intelligence Platform | v1.0.0")

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def generate_elite_analysis():
    """Generate comprehensive elite-level tactical analysis"""
    return {
        'matchup_verdict': '''
        **Team A** demonstrates superior structural dominance through aggressive Gegenpressing execution, 
        maintaining High-Press Final Third intensity throughout. Their compact 4-3-3 formation creates 
        constant pressure in the attacking third, forcing **Team B** into hurried decisions. However, 
        this aggressive positioning exposes vulnerabilities to counter-attacks down the flanks.
        
        **Team B** maintains defensive discipline through a disciplined Park the Bus 5-4-1 formation, 
        effectively neutralizing Team A's attacking play. Their Low-Block Defensive Third setup provides 
        structural stability but limits their ability to control possession and create attacking opportunities.
        
        **Tactical Winner:** Team A's pressing intensity and midfield control give them the advantage, 
        though Team B's defensive organization prevents a dominant performance.
        ''',
        'team_a': {
            'style': 'Gegenpressing',
            'formation': '4-3-3',
            'compactness': 8.2,
            'width': 7.5,
            'pressing_zone': 'High-Press Final Third',
            'players': [
                {'id': 1, 'role': 'Sweeper Keeper', 'activity': 6, 'zone': 'Defensive Third - Center', 'pressure': 3, 'defense': 9, 'strengths': ['Distribution', 'Positioning'], 'weaknesses': ['Limited Sweeping']},
                {'id': 2, 'role': 'Ball-Winning Defender', 'activity': 8, 'zone': 'Defensive Third - Left', 'pressure': 8, 'defense': 9, 'strengths': ['Tackling', 'Interceptions'], 'weaknesses': ['Positioning Gaps']},
                {'id': 3, 'role': 'Ball-Winning Defender', 'activity': 8, 'zone': 'Defensive Third - Right', 'pressure': 8, 'defense': 9, 'strengths': ['Physical Presence', 'Blocking'], 'weaknesses': ['Aerial Weakness']},
                {'id': 4, 'role': 'Box-to-Box Midfielder', 'activity': 9, 'zone': 'Midfield - Center', 'pressure': 9, 'defense': 7, 'strengths': ['Work Rate', 'Transition Play'], 'weaknesses': ['Defensive Gaps']},
                {'id': 5, 'role': 'Inverted Winger', 'activity': 8, 'zone': 'Attacking Third - Left', 'pressure': 7, 'defense': 4, 'strengths': ['Dribbling', 'Creativity'], 'weaknesses': ['Defensive Liability']},
                {'id': 6, 'role': 'Target Forward', 'activity': 7, 'zone': 'Attacking Third - Center', 'pressure': 6, 'defense': 2, 'strengths': ['Positioning', 'Finishing'], 'weaknesses': ['Work Rate']},
            ]
        },
        'team_b': {
            'style': 'Park the Bus',
            'formation': '5-4-1',
            'compactness': 7.8,
            'width': 6.2,
            'pressing_zone': 'Low-Block Defensive Third',
            'players': [
                {'id': 1, 'role': 'Sweeper Keeper', 'activity': 5, 'zone': 'Defensive Third - Center', 'pressure': 2, 'defense': 9, 'strengths': ['Distribution', 'Command'], 'weaknesses': ['Limited Sweeping']},
                {'id': 2, 'role': 'Ball-Winning Defender', 'activity': 7, 'zone': 'Defensive Third - Left', 'pressure': 6, 'defense': 9, 'strengths': ['Tackling', 'Positioning'], 'weaknesses': ['Aerial Weakness']},
                {'id': 3, 'role': 'Ball-Winning Defender', 'activity': 7, 'zone': 'Defensive Third - Right', 'pressure': 6, 'defense': 9, 'strengths': ['Blocking', 'Interceptions'], 'weaknesses': ['Positioning Gaps']},
                {'id': 4, 'role': 'Box-to-Box Midfielder', 'activity': 6, 'zone': 'Midfield - Center', 'pressure': 5, 'defense': 7, 'strengths': ['Transition Play', 'Versatility'], 'weaknesses': ['Defensive Gaps']},
                {'id': 5, 'role': 'Target Forward', 'activity': 4, 'zone': 'Attacking Third - Center', 'pressure': 3, 'defense': 2, 'strengths': ['Hold-up Play', 'Positioning'], 'weaknesses': ['Work Rate']},
            ]
        },
        'weaknesses': [
            {
                'team': 'A',
                'issue': 'Counter-Attack Vulnerability',
                'zone': 'Left Channel',
                'severity': 8,
                'recommendation': 'Deploy a deeper defensive line during attacking phases. Add a defensive midfielder to cover transitions. Instruct fullbacks to maintain defensive positioning when team is in possession.',
                'formation_adjustment': 'Shift from 4-3-3 to 4-2-4 to add defensive stability'
            },
            {
                'team': 'B',
                'issue': 'Narrow Structural Bias',
                'zone': 'Central Midfield',
                'severity': 7,
                'recommendation': 'Instruct fullbacks to hold the touchline and maintain width. Shift midfielders to support wing play for better horizontal coverage. Consider 4-4-2 formation for improved width.',
                'formation_adjustment': 'Adjust from 5-4-1 to 4-4-2 to increase attacking width'
            }
        ],
        'coaching_commentary': '''
        Team A\'s Gegenpressing strategy creates relentless pressure in the attacking third, forcing Team B into hurried decisions and turnovers. 
        The aggressive positioning of their midfielders and forwards generates constant attacking opportunities. However, this intensity leaves gaps 
        for counter-attacks, particularly down the left flank where their fullback is pushed high. 
        
        Team B\'s defensive organization is impressive, with their compact 5-4-1 shape effectively neutralizing Team A\'s attacking play. 
        The low block provides structural stability, but the narrow midfield limits their ability to control possession and create chances. 
        They should exploit the width more effectively to stretch Team A\'s defense.
        
        The key tactical battle occurs in the midfield where Team A\'s intensity advantage is most pronounced. Team B must improve their 
        transition play and utilize set pieces more effectively to create scoring opportunities.
        '''
    }
